"""
Posielanie správ cez TCP a počítanie prenesených bajtov.

Každá správa sa skladá z niekoľkých polí (bajty). Každé pole sa pošle ako:
    [4 bajty = dĺžka poľa][samotné pole]
Na začiatku správy sú 4 bajty s počtom polí. Nepoužívame JSON ani base64,
aby namerané veľkosti presne zodpovedali veľkosti kľúčov a podpisov.
"""

import math
import socket
import struct

MSS = 1460  # max. dát v jednom TCP pakete na bežnej sieti (Ethernet, MTU 1500)

PORT = 5050


def _prijmi_presne(sock, n):
    data = b""
    while len(data) < n:
        kus = sock.recv(n - len(data))
        if not kus:
            raise ConnectionError("Spojenie bolo ukončené.")
        data += kus
    return data


class Spojenie:
    """TCP spojenie, ktoré si pamätá, koľko bajtov a paketov prešlo."""

    def __init__(self, sock):
        self.sock = sock
        self.odoslane_bajty = 0
        self.prijate_bajty = 0
        self.odoslane_pakety = 0
        self.prijate_pakety = 0

    @classmethod
    def pripoj(cls, adresa="127.0.0.1", port=PORT):
        sock = socket.create_connection((adresa, port))
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        return cls(sock)

    def posli(self, *polia):
        polia = [p.encode() if isinstance(p, str) else p for p in polia]
        data = struct.pack("!I", len(polia))
        for p in polia:
            data += struct.pack("!I", len(p)) + p
        self.sock.sendall(data)
        self.odoslane_bajty += len(data)
        self.odoslane_pakety += math.ceil(len(data) / MSS)

    def prijmi(self):
        hlavicka = _prijmi_presne(self.sock, 4)
        (pocet,) = struct.unpack("!I", hlavicka)
        polia, spolu = [], 4
        for _ in range(pocet):
            (dlzka,) = struct.unpack("!I", _prijmi_presne(self.sock, 4))
            polia.append(_prijmi_presne(self.sock, dlzka))
            spolu += 4 + dlzka
        self.prijate_bajty += spolu
        self.prijate_pakety += math.ceil(spolu / MSS)
        return polia

    def zavri(self):
        self.sock.close()
