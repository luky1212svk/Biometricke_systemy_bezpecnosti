"""
Zjednodušená (simulovaná) biometria.

Reálny systém (napr. rozpoznávanie tváre) premení fotku tváre na tzv.
šablónu - zoznam čísel (vektor), ktorý tvár popisuje. Dve fotky tej istej
osoby dajú podobné vektory, fotky rôznych osôb dajú odlišné vektory.

Tu fotky nemáme, takže šablóny simulujeme:
  - každý používateľ má svoj "základný" vektor 128 čísel (ako tvár),
  - každé nasnímanie = základný vektor + malý náhodný šum
    (iné svetlo, iný uhol, ...),
  - porovnanie = vzdialenosť dvoch vektorov; ak je menšia ako PRAH,
    ide o tú istú osobu.

Šifrovanie pracuje s bajtmi, takže je mu jedno, či šablóna pochádza
z reálnej tváre alebo zo simulácie - veľkosti správ aj časy sú rovnaké.
"""

import math
import random
import struct

DLZKA_SABLONY = 128   # počet čísel v šablóne (bežné pri tvárach)
SUM = 0.03           # veľkosť náhodného šumu pri každom nasnímaní
PRAH = 0.8            # max. vzdialenosť, pri ktorej osobu prijmeme


def vytvor_osobu(cislo_osoby):
    nahoda = random.Random(cislo_osoby)
    vektor = [nahoda.gauss(0, 1) for _ in range(DLZKA_SABLONY)]
    dlzka = math.sqrt(sum(x * x for x in vektor))
    return [x / dlzka for x in vektor]


def nasnimaj(osoba):
    """Jedno nasnímanie snímačom = osoba + šum."""
    return [x + random.gauss(0, SUM) for x in osoba]


def porovnaj(sablona_a, sablona_b):
    """Vráti (zhoda True/False, vzdialenosť)."""
    vzdialenost = math.sqrt(sum((a - b) ** 2 for a, b in zip(sablona_a, sablona_b)))
    return vzdialenost < PRAH, vzdialenost


def na_bajty(sablona):
    """Šablóna -> bajty (128 čísel * 4 B = 512 B)."""
    return struct.pack(f"{DLZKA_SABLONY}f", *sablona)


def z_bajtov(data):
    return list(struct.unpack(f"{DLZKA_SABLONY}f", data))
