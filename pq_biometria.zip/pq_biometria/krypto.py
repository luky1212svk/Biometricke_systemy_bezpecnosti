"""
Kryptografické funkcie pre dva režimy:

  "klasicky"  = X25519 (výmena kľúča) + Ed25519 (podpis)
                -> dnešný štandard, prelomiteľný kvantovým počítačom (Shor)

  "pq"        = ML-KEM-768 (výmena kľúča) + ML-DSA-65 (podpis)
                -> post-kvantové štandardy NIST (FIPS 203 a FIPS 204)

V oboch režimoch sa samotné dáta šifrujú symetricky cez AES-256-GCM.
AES-256 zostáva bezpečný aj voči kvantovým počítačom (Grover len polovične
znižuje efektívnu dĺžku kľúča -> 128 bitov, čo stačí).

Každý režim má rovnaké tri kroky výmeny kľúča:
  1. server:  vytvor_kluc_servera()     -> (tajny_kluc, verejny_kluc_bajty)
  2. klient:  zabal_tajomstvo(verejny)  -> (spolocne_tajomstvo, sprava_pre_server)
  3. server:  rozbal_tajomstvo(tajny, sprava) -> spolocne_tajomstvo
Výsledok: klient aj server majú rovnaké spoločné tajomstvo, z ktorého
sa odvodí AES kľúč. Útočník, ktorý počúva sieť, ho nezistí.
"""

import os

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, mldsa, mlkem, x25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

REZIMY = ["klasicky", "pq"]

NAZVY_ALGORITMOV = {
    "klasicky": {"vymena": "X25519", "podpis": "Ed25519"},
    "pq": {"vymena": "ML-KEM-768", "podpis": "ML-DSA-65"},
}


# ---------------------------------------------------------------------------
# 1) Výmena kľúča
# ---------------------------------------------------------------------------

def vytvor_kluc_servera(rezim):
    """Server vytvorí nový (jednorazový) pár kľúčov pre jedno prihlásenie."""
    if rezim == "klasicky":
        tajny = x25519.X25519PrivateKey.generate()
    else:
        tajny = mlkem.MLKEM768PrivateKey.generate()
    return tajny, tajny.public_key().public_bytes_raw()


def zabal_tajomstvo(rezim, verejny_kluc_servera):
    """Klient vytvorí spoločné tajomstvo a správu, ktorú pošle serveru."""
    if rezim == "klasicky":
        # X25519: klient si vytvorí vlastný pár kľúčov, pošle svoj verejný kľúč
        tajny_klienta = x25519.X25519PrivateKey.generate()
        server = x25519.X25519PublicKey.from_public_bytes(verejny_kluc_servera)
        tajomstvo = tajny_klienta.exchange(server)
        sprava = tajny_klienta.public_key().public_bytes_raw()
    else:
        # ML-KEM: klient "zabalí" náhodné tajomstvo verejným kľúčom servera
        server = mlkem.MLKEM768PublicKey.from_public_bytes(verejny_kluc_servera)
        tajomstvo, sprava = server.encapsulate()
    return tajomstvo, sprava


def rozbal_tajomstvo(rezim, tajny_kluc_servera, sprava_od_klienta):
    """Server zo správy klienta získa rovnaké spoločné tajomstvo."""
    if rezim == "klasicky":
        klient = x25519.X25519PublicKey.from_public_bytes(sprava_od_klienta)
        return tajny_kluc_servera.exchange(klient)
    return tajny_kluc_servera.decapsulate(sprava_od_klienta)


def odvod_aes_kluc(tajomstvo):
    """Zo spoločného tajomstva vyrobí 256-bitový AES kľúč (HKDF-SHA256)."""
    return HKDF(
        algorithm=hashes.SHA256(), length=32, salt=None, info=b"biometria-aes"
    ).derive(tajomstvo)


# ---------------------------------------------------------------------------
# 2) Digitálny podpis (overenie, že správa prišla od správneho zariadenia)
# ---------------------------------------------------------------------------

def vytvor_podpisovy_kluc(rezim):
    """Vráti (tajny_kluc, verejny_kluc_bajty)."""
    if rezim == "klasicky":
        tajny = ed25519.Ed25519PrivateKey.generate()
    else:
        tajny = mldsa.MLDSA65PrivateKey.generate()
    return tajny, tajny.public_key().public_bytes_raw()


def uloz_tajny_kluc(tajny_kluc, cesta):
    with open(cesta, "wb") as f:
        f.write(tajny_kluc.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        ))


def nacitaj_tajny_kluc(cesta):
    with open(cesta, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def podpis(tajny_kluc, data):
    return tajny_kluc.sign(data)


def over_podpis(rezim, verejny_kluc_bajty, data, podpis_bajty):
    """True ak je podpis platný, inak False."""
    if rezim == "klasicky":
        verejny = ed25519.Ed25519PublicKey.from_public_bytes(verejny_kluc_bajty)
    else:
        verejny = mldsa.MLDSA65PublicKey.from_public_bytes(verejny_kluc_bajty)
    try:
        verejny.verify(podpis_bajty, data)
        return True
    except InvalidSignature:
        return False


# ---------------------------------------------------------------------------
# 3) Symetrické šifrovanie dát (AES-256-GCM)
# ---------------------------------------------------------------------------

def zasifruj(aes_kluc, data, doplnok=b""):
    """Vráti (nonce, zasifrovane). 'doplnok' sa nešifruje, ale je chránený
    proti zmene (napr. meno používateľa)."""
    nonce = os.urandom(12)
    return nonce, AESGCM(aes_kluc).encrypt(nonce, data, doplnok)


def desifruj(aes_kluc, nonce, zasifrovane, doplnok=b""):
    """Vráti dáta, alebo None ak niekto dáta pozmenil."""
    try:
        return AESGCM(aes_kluc).decrypt(nonce, zasifrovane, doplnok)
    except InvalidTag:
        return None
