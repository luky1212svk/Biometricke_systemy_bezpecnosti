"""
Hlavný skript - spustí celé meranie a vytvorí výsledky do priečinka 'vysledky'.

Spustenie:  python meranie.py

Čo sa meria (pre klasický aj post-kvantový režim):
  1. Veľkosti kľúčov, podpisov a správ (v bajtoch).
  2. Rýchlosť jednotlivých kryptografických operácií (v milisekundách).
  3. Celé prihlásenie cez sieť: koľko bajtov a TCP paketov sa prenesie
     a ako dlho to trvá.
  4. Bezpečnostné scenáre:
       - správna osoba          -> má byť PRIJATÁ
       - iná osoba (iná tvár)   -> má byť ZAMIETNUTÁ
       - útočník zmení správu   -> má byť ZAMIETNUTÁ
  5. Odhad času prenosu na pomalších sieťach (napr. 1 Mbit/s).
"""

import csv
import os
import statistics
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

import biometria  # noqa: E402
import krypto  # noqa: E402
import server  # noqa: E402
from klient import prihlasenie, registracia  # noqa: E402

PORT_MERANIA = 5051
POCET_OPAKOVANI_OPERACII = 300   # koľkokrát zmerať každú operáciu
POCET_OSOB = 10                  # koľko používateľov zaregistrovať
POCET_PRIHLASENI = 20            # koľko správnych prihlásení na osobu
POCET_UTOKOV = 5                 # koľko pozmenených správ na osobu
RYCHLOSTI_SIETE = [0.1, 0.25, 0.5, 1, 2, 5, 10, 100]  # Mbit/s

VYSTUP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vysledky")

FARBY = {"klasicky": "#2a78d6", "pq": "#eb6834"}
POPISY = {"klasicky": "Klasický (X25519 + Ed25519)",
          "pq": "Post-kvantový (ML-KEM-768 + ML-DSA-65)"}


# ---------------------------------------------------------------------------
# 1 + 2) Veľkosti a rýchlosť operácií
# ---------------------------------------------------------------------------

def _priemer_ms(funkcia, n=POCET_OPAKOVANI_OPERACII):
    casy = []
    for _ in range(n):
        t = time.perf_counter()
        funkcia()
        casy.append((time.perf_counter() - t) * 1000)
    return statistics.mean(casy)


def zmeraj_operacie(rezim):
    tajny_s, verejny_s = krypto.vytvor_kluc_servera(rezim)
    tajomstvo, sprava = krypto.zabal_tajomstvo(rezim, verejny_s)
    tajny_p, verejny_p = krypto.vytvor_podpisovy_kluc(rezim)
    data = os.urandom(600)
    podpis = krypto.podpis(tajny_p, data)

    velkosti = {
        "verejny kluc vymeny (B)": len(verejny_s),
        "zabalene tajomstvo (B)": len(sprava),
        "verejny podpisovy kluc (B)": len(verejny_p),
        "podpis (B)": len(podpis),
    }
    casy = {
        "Vytvorenie kľúča (server)": _priemer_ms(lambda: krypto.vytvor_kluc_servera(rezim)),
        "Zabalenie tajomstva (klient)": _priemer_ms(lambda: krypto.zabal_tajomstvo(rezim, verejny_s)),
        "Rozbalenie tajomstva (server)": _priemer_ms(lambda: krypto.rozbal_tajomstvo(rezim, tajny_s, sprava)),
        "Podpísanie": _priemer_ms(lambda: krypto.podpis(tajny_p, data)),
        "Overenie podpisu": _priemer_ms(lambda: krypto.over_podpis(rezim, verejny_p, data, podpis)),
    }
    return velkosti, casy


# ---------------------------------------------------------------------------
# 3 + 4) Prihlasovanie cez sieť
# ---------------------------------------------------------------------------

def zmeraj_prihlasenia(rezim):
    riadky = []
    osoby = {i: biometria.vytvor_osobu(i) for i in range(1, POCET_OSOB + 1)}

    for i, osoba in osoby.items():
        meno = f"pouzivatel{i}"
        kluc, v = registracia(rezim, meno, biometria.nasnimaj(osoba), port=PORT_MERANIA)
        riadky.append({"rezim": rezim, "scenar": "registracia", "ocakavane": "PRIJATY", **v})

        # správna osoba
        for _ in range(POCET_PRIHLASENI):
            v = prihlasenie(rezim, meno, biometria.nasnimaj(osoba), kluc, port=PORT_MERANIA)
            riadky.append({"rezim": rezim, "scenar": "spravna osoba", "ocakavane": "PRIJATY", **v})

        # iná osoba sa pokúša prihlásiť na cudzom zariadení
        for j, ina in osoby.items():
            if j != i:
                v = prihlasenie(rezim, meno, biometria.nasnimaj(ina), kluc, port=PORT_MERANIA)
                riadky.append({"rezim": rezim, "scenar": "ina osoba", "ocakavane": "ZAMIETNUTY", **v})

        # útočník po ceste zmení správu
        for _ in range(POCET_UTOKOV):
            v = prihlasenie(rezim, meno, biometria.nasnimaj(osoba), kluc,
                            port=PORT_MERANIA, pokazit=True)
            riadky.append({"rezim": rezim, "scenar": "zmenena sprava", "ocakavane": "ZAMIETNUTY", **v})
    return riadky


# ---------------------------------------------------------------------------
# Uloženie a grafy
# ---------------------------------------------------------------------------

def uloz_csv(nazov, riadky):
    with open(os.path.join(VYSTUP, nazov), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(riadky[0].keys()), delimiter=";")
        w.writeheader()
        w.writerows(riadky)


def _styl(ax, titul, os_y):
    ax.set_title(titul, loc="left", fontsize=12, color="#0b0b0b")
    ax.set_ylabel(os_y, color="#52514e")
    ax.spines[["top", "right"]].set_visible(False)
    ax.spines[["left", "bottom"]].set_color("#c3c2b7")
    ax.tick_params(colors="#52514e")
    ax.grid(axis="y", color="#e6e5e0", linewidth=0.8)
    ax.set_axisbelow(True)


def graf_bajty(suhrn):
    fig, ax = plt.subplots(figsize=(7, 4), dpi=150)
    skupiny = ["odoslané (klient → server)", "prijaté (server → klient)", "spolu"]
    kluce = ["odoslane_B", "prijate_B", "spolu_B"]
    sirka = 0.38
    for k, rezim in enumerate(krypto.REZIMY):
        hodnoty = [suhrn[rezim][x] for x in kluce]
        pozicie = [i + (k - 0.5) * (sirka + 0.02) for i in range(len(skupiny))]
        stlpce = ax.bar(pozicie, hodnoty, sirka, color=FARBY[rezim], label=POPISY[rezim])
        ax.bar_label(stlpce, labels=[f"{h:,.0f} B".replace(",", " ") for h in hodnoty],
                     padding=3, fontsize=8, color="#52514e")
    ax.set_xticks(range(len(skupiny)), skupiny)
    _styl(ax, "Prenesené dáta pri jednom prihlásení", "bajty")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    fig.tight_layout()
    fig.savefig(os.path.join(VYSTUP, "graf_prenesene_bajty.png"))
    plt.close(fig)


def graf_operacie(casy):
    fig, ax = plt.subplots(figsize=(8, 4.2), dpi=150)
    operacie = list(casy["klasicky"].keys())
    sirka = 0.38
    for k, rezim in enumerate(krypto.REZIMY):
        hodnoty = [casy[rezim][o] for o in operacie]
        pozicie = [i + (k - 0.5) * (sirka + 0.02) for i in range(len(operacie))]
        stlpce = ax.bar(pozicie, hodnoty, sirka, color=FARBY[rezim], label=POPISY[rezim])
        ax.bar_label(stlpce, labels=[f"{h:.3f}" for h in hodnoty],
                     padding=3, fontsize=7, color="#52514e")
    ax.set_xticks(range(len(operacie)), [o.replace(" (", "\n(") for o in operacie], fontsize=8)
    _styl(ax, "Priemerný čas kryptografických operácií", "milisekundy")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    fig.tight_layout()
    fig.savefig(os.path.join(VYSTUP, "graf_cas_operacii.png"))
    plt.close(fig)


def graf_rychlost_siete(suhrn):
    fig, ax = plt.subplots(figsize=(7, 4), dpi=150)
    for rezim in krypto.REZIMY:
        bajty = suhrn[rezim]["spolu_B"]
        casy = [bajty * 8 / (r * 1_000_000) * 1000 for r in RYCHLOSTI_SIETE]
        ax.plot(RYCHLOSTI_SIETE, casy, color=FARBY[rezim], linewidth=2,
                marker="o", markersize=5, label=POPISY[rezim])
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xticks(RYCHLOSTI_SIETE, [f"{r:g}" for r in RYCHLOSTI_SIETE])
    ax.set_yticks([0.1, 1, 10, 100, 1000], ["0,1", "1", "10", "100", "1000"])
    ax.minorticks_off()
    ax.set_xlabel("rýchlosť siete (Mbit/s)", color="#52514e")
    _styl(ax, "Čas prenosu dát jedného prihlásenia podľa rýchlosti siete", "milisekundy")
    ax.grid(axis="x", color="#e6e5e0", linewidth=0.8)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(VYSTUP, "graf_rychlost_siete.png"))
    plt.close(fig)


# ---------------------------------------------------------------------------

def main():
    os.makedirs(VYSTUP, exist_ok=True)
    server.vymaz_databazu()
    srv = server.spusti_na_pozadi(port=PORT_MERANIA)

    velkosti, casy, prihlasenia = {}, {}, []
    for rezim in krypto.REZIMY:
        print(f"Meriam režim: {POPISY[rezim]} ...")
        velkosti[rezim], casy[rezim] = zmeraj_operacie(rezim)
        prihlasenia += zmeraj_prihlasenia(rezim)
    srv.shutdown()

    # --- súhrn prihlásení (len úspešné prihlásenia správnej osoby) ---
    suhrn = {}
    for rezim in krypto.REZIMY:
        ok = [r for r in prihlasenia
              if r["rezim"] == rezim and r["scenar"] == "spravna osoba"]
        suhrn[rezim] = {
            "odoslane_B": statistics.mean(r["odoslane_B"] for r in ok),
            "prijate_B": statistics.mean(r["prijate_B"] for r in ok),
            "spolu_B": statistics.mean(r["spolu_B"] for r in ok),
            "pakety": statistics.mean(r["pakety"] for r in ok),
            "cas_ms": statistics.median(r["cas_ms"] for r in ok),
        }

    # --- uloženie CSV ---
    for r in prihlasenia:
        r["cas_ms"] = round(r["cas_ms"], 3)
    uloz_csv("prihlasenia.csv", prihlasenia)
    uloz_csv("velkosti.csv", [{"rezim": r, **velkosti[r]} for r in krypto.REZIMY])
    uloz_csv("cas_operacii_ms.csv",
             [{"rezim": r, **{k: round(v, 4) for k, v in casy[r].items()}} for r in krypto.REZIMY])
    uloz_csv("suhrn.csv", [{"rezim": r, **{k: round(v, 2) for k, v in suhrn[r].items()}}
                           for r in krypto.REZIMY])

    # --- grafy ---
    graf_bajty(suhrn)
    graf_operacie(casy)
    graf_rychlost_siete(suhrn)

    # --- výpis do konzoly ---
    print("\n=== VEĽKOSTI (bajty) ===")
    print(f"{'':30}{'klasický':>12}{'post-kvantový':>16}")
    for k in velkosti["klasicky"]:
        print(f"{k:30}{velkosti['klasicky'][k]:>12}{velkosti['pq'][k]:>16}")

    print("\n=== ČAS OPERÁCIÍ (ms, priemer) ===")
    for k in casy["klasicky"]:
        print(f"{k:30}{casy['klasicky'][k]:>12.4f}{casy['pq'][k]:>16.4f}")

    print("\n=== JEDNO PRIHLÁSENIE CEZ SIEŤ ===")
    for k, popis in [("spolu_B", "prenesené bajty"), ("pakety", "TCP pakety (MTU 1500)"),
                     ("cas_ms", "čas (ms, medián, localhost)")]:
        print(f"{popis:30}{suhrn['klasicky'][k]:>12.1f}{suhrn['pq'][k]:>16.1f}")
    pomer = suhrn["pq"]["spolu_B"] / suhrn["klasicky"]["spolu_B"]
    print(f"Post-kvantový režim prenesie {pomer:.1f}x viac dát.")

    print("\n=== BEZPEČNOSTNÉ SCENÁRE ===")
    for rezim in krypto.REZIMY:
        for scenar in ["spravna osoba", "ina osoba", "zmenena sprava"]:
            vyber = [r for r in prihlasenia if r["rezim"] == rezim and r["scenar"] == scenar]
            spravne = sum(r["vysledok"] == r["ocakavane"] for r in vyber)
            print(f"{rezim:10} {scenar:16} správne vyhodnotené {spravne}/{len(vyber)}")

    print(f"\nVýsledky (CSV + grafy) sú v priečinku: {VYSTUP}")


if __name__ == "__main__":
    main()
