"""
Klient = zariadenie so snímačom (napr. terminál pri dverách, mobil).

Príklady spustenia (server musí bežať v inom termináli):
    python klient.py registracia --meno jano --osoba 1 --rezim pq
    python klient.py prihlasenie --meno jano --osoba 1 --rezim pq   -> PRIJATY
    python klient.py prihlasenie --meno jano --osoba 2 --rezim pq   -> ZAMIETNUTY

--osoba = čia tvár sa práve snímá (1, 2, 3, ...).

Priebeh prihlásenia:
  1. klient -> server : "PRIHLASENIE", režim, meno
  2. server -> klient : jednorazový verejný kľúč + podpis servera
  3. klient           : overí podpis servera (rozpráva sa so správnym serverom?)
                        vytvorí spoločné tajomstvo -> AES kľúč
                        zašifruje šablónu, celé to podpíše kľúčom zariadenia
     klient -> server : zabalené tajomstvo, zašifrovaná šablóna, podpis
  4. server -> klient : PRIJATY / ZAMIETNUTY
"""

import argparse
import os
import time

import biometria
import krypto
from server import PRIECINOK, cesta_verejneho_kluca_servera
from siet import PORT, Spojenie


def _nacitaj_verejny_kluc_servera(rezim):
    with open(cesta_verejneho_kluca_servera(rezim), "rb") as f:
        return f.read()


def _vysledok(spoj, polia, zaciatok):
    spoj.zavri()
    return {
        "vysledok": polia[0].decode(),
        "dovod": polia[1].decode() if len(polia) > 1 else "",
        "odoslane_B": spoj.odoslane_bajty,
        "prijate_B": spoj.prijate_bajty,
        "spolu_B": spoj.odoslane_bajty + spoj.prijate_bajty,
        "pakety": spoj.odoslane_pakety + spoj.prijate_pakety,
        "cas_ms": (time.perf_counter() - zaciatok) * 1000,
    }


def _zaciatok_spojenia(typ, rezim, meno, adresa, port):
    """Kroky 1 a 2 + overenie servera. Vráti (spoj, verejny_jednorazovy)."""
    spoj = Spojenie.pripoj(adresa, port)
    spoj.posli(typ, rezim, meno)
    verejny_jednorazovy, podpis_servera = spoj.prijmi()
    if not krypto.over_podpis(rezim, _nacitaj_verejny_kluc_servera(rezim),
                              verejny_jednorazovy + meno.encode(), podpis_servera):
        spoj.zavri()
        raise RuntimeError("Podpis servera nesedí - možný útok (falošný server)!")
    return spoj, verejny_jednorazovy


def registracia(rezim, meno, sablona, adresa="127.0.0.1", port=PORT):
    """Vráti (tajny_kluc_zariadenia, vysledok)."""
    zaciatok = time.perf_counter()
    kluc_zariadenia, verejny_kluc_zariadenia = krypto.vytvor_podpisovy_kluc(rezim)

    spoj, verejny_jednorazovy = _zaciatok_spojenia("REGISTRACIA", rezim, meno,
                                                   adresa, port)
    tajomstvo, sprava_vymeny = krypto.zabal_tajomstvo(rezim, verejny_jednorazovy)
    aes = krypto.odvod_aes_kluc(tajomstvo)
    nonce, zasifrovane = krypto.zasifruj(aes, biometria.na_bajty(sablona),
                                         meno.encode() + verejny_kluc_zariadenia)
    spoj.posli(sprava_vymeny, nonce, zasifrovane, verejny_kluc_zariadenia)
    return kluc_zariadenia, _vysledok(spoj, spoj.prijmi(), zaciatok)


def prihlasenie(rezim, meno, sablona, kluc_zariadenia,
                adresa="127.0.0.1", port=PORT, pokazit=False):
    """pokazit=True simuluje útočníka, ktorý po ceste zmení 1 bajt správy."""
    zaciatok = time.perf_counter()
    spoj, verejny_jednorazovy = _zaciatok_spojenia("PRIHLASENIE", rezim, meno,
                                                   adresa, port)
    tajomstvo, sprava_vymeny = krypto.zabal_tajomstvo(rezim, verejny_jednorazovy)
    aes = krypto.odvod_aes_kluc(tajomstvo)
    nonce, zasifrovane = krypto.zasifruj(aes, biometria.na_bajty(sablona),
                                         meno.encode())
    podpis = krypto.podpis(kluc_zariadenia,
                           sprava_vymeny + nonce + zasifrovane + verejny_jednorazovy)
    if pokazit:
        zasifrovane = bytes([zasifrovane[0] ^ 0xFF]) + zasifrovane[1:]
    spoj.posli(sprava_vymeny, nonce, zasifrovane, podpis)
    return _vysledok(spoj, spoj.prijmi(), zaciatok)


# ---------------------------------------------------------------------------
# Spustenie z príkazového riadku
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Biometrický klient")
    parser.add_argument("akcia", choices=["registracia", "prihlasenie"])
    parser.add_argument("--meno", required=True)
    parser.add_argument("--osoba", type=int, default=1, help="čia tvár sa snímá")
    parser.add_argument("--rezim", choices=krypto.REZIMY, default="pq")
    parser.add_argument("--server", default="127.0.0.1", help="IP adresa servera")
    parser.add_argument("--port", type=int, default=PORT)
    args = parser.parse_args()

    subor_kluca = os.path.join(PRIECINOK, f"zariadenie_{args.meno}_{args.rezim}.pem")
    sablona = biometria.nasnimaj(biometria.vytvor_osobu(args.osoba))

    if args.akcia == "registracia":
        kluc, v = registracia(args.rezim, args.meno, sablona, args.server, args.port)
        krypto.uloz_tajny_kluc(kluc, subor_kluca)
    else:
        if not os.path.exists(subor_kluca):
            raise SystemExit("Toto zariadenie nie je zaregistrované. Najprv spusti registráciu.")
        kluc = krypto.nacitaj_tajny_kluc(subor_kluca)
        v = prihlasenie(args.rezim, args.meno, sablona, kluc, args.server, args.port)

    print(f"{v['vysledok']}  ({v['dovod']})")
    print(f"Prenesené: {v['odoslane_B']} B odoslané + {v['prijate_B']} B prijaté "
          f"= {v['spolu_B']} B, približne {v['pakety']} TCP paketov, "
          f"čas {v['cas_ms']:.1f} ms")
