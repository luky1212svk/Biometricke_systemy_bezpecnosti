"""
Autentifikačný server.

Spustenie (samostatne):   python server.py
Na inom počítači v sieti: python server.py --adresa 0.0.0.0

Server robí dve veci:
  REGISTRACIA - prijme šablónu tváre a verejný podpisový kľúč zariadenia
                a uloží ich do databázy (šablóna je v databáze zašifrovaná).
  PRIHLASENIE - overí podpis zariadenia, dešifruje šablónu a porovná ju
                s uloženou šablónou.
"""

import argparse
import json
import os
import socketserver
import threading

import biometria
import krypto
from siet import PORT, Spojenie

PRIECINOK = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
SUBOR_DATABAZY = os.path.join(PRIECINOK, "databaza.json")
SUBOR_KLUCA_DATABAZY = os.path.join(PRIECINOK, "kluc_databazy.bin")

_zamok = threading.Lock()


# ---------------------------------------------------------------------------
# Kľúče servera
# ---------------------------------------------------------------------------

def cesta_verejneho_kluca_servera(rezim):
    return os.path.join(PRIECINOK, f"server_{rezim}_verejny.bin")


def priprav_kluce_servera():
    """Pri prvom spustení vytvorí dlhodobé kľúče servera.

    - podpisový kľúč servera (pre každý režim): klient ním overí, že sa
      rozpráva so skutočným serverom (podobne ako certifikát pri HTTPS),
    - AES kľúč databázy: šablóny sa v databáze ukladajú zašifrované.
    """
    os.makedirs(PRIECINOK, exist_ok=True)
    for rezim in krypto.REZIMY:
        tajny_subor = os.path.join(PRIECINOK, f"server_{rezim}.pem")
        if not os.path.exists(tajny_subor):
            tajny, verejny = krypto.vytvor_podpisovy_kluc(rezim)
            krypto.uloz_tajny_kluc(tajny, tajny_subor)
            with open(cesta_verejneho_kluca_servera(rezim), "wb") as f:
                f.write(verejny)
    if not os.path.exists(SUBOR_KLUCA_DATABAZY):
        with open(SUBOR_KLUCA_DATABAZY, "wb") as f:
            f.write(os.urandom(32))


def _nacitaj_kluce():
    podpisove = {
        r: krypto.nacitaj_tajny_kluc(os.path.join(PRIECINOK, f"server_{r}.pem"))
        for r in krypto.REZIMY
    }
    with open(SUBOR_KLUCA_DATABAZY, "rb") as f:
        kluc_db = f.read()
    return podpisove, kluc_db


# ---------------------------------------------------------------------------
# Databáza (jednoduchý JSON súbor)
# ---------------------------------------------------------------------------

def _nacitaj_db():
    if not os.path.exists(SUBOR_DATABAZY):
        return {}
    with open(SUBOR_DATABAZY, encoding="utf-8") as f:
        return json.load(f)


def _uloz_db(db):
    with open(SUBOR_DATABAZY, "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2)


def vymaz_databazu():
    if os.path.exists(SUBOR_DATABAZY):
        os.remove(SUBOR_DATABAZY)


# ---------------------------------------------------------------------------
# Obsluha jedného klienta
# ---------------------------------------------------------------------------

class Obsluha(socketserver.BaseRequestHandler):

    def handle(self):
        spoj = Spojenie(self.request)
        try:
            self._obsluz(spoj)
        except ConnectionError:
            pass

    def _obsluz(self, spoj):
        podpisove_kluce, kluc_db = self.server.kluce

        # 1) Klient: čo chce, v akom režime a kto je
        typ, rezim, meno = [p.decode() for p in spoj.prijmi()]
        if rezim not in krypto.REZIMY:
            spoj.posli("ZAMIETNUTY", "neznamy rezim")
            return

        # 2) Server: jednorazový kľúč na výmenu + podpis servera
        tajny_jednorazovy, verejny_jednorazovy = krypto.vytvor_kluc_servera(rezim)
        podpis_servera = krypto.podpis(
            podpisove_kluce[rezim], verejny_jednorazovy + meno.encode()
        )
        spoj.posli(verejny_jednorazovy, podpis_servera)

        # 3) Klient: zabalené tajomstvo + zašifrovaná šablóna (+ podpis)
        polia = spoj.prijmi()
        sprava_vymeny, nonce, zasifrovane = polia[0], polia[1], polia[2]

        if typ == "REGISTRACIA":
            verejny_kluc_zariadenia = polia[3]
            tajomstvo = krypto.rozbal_tajomstvo(rezim, tajny_jednorazovy, sprava_vymeny)
            aes = krypto.odvod_aes_kluc(tajomstvo)
            sablona = krypto.desifruj(aes, nonce, zasifrovane,
                                      meno.encode() + verejny_kluc_zariadenia)
            if sablona is None:
                spoj.posli("ZAMIETNUTY", "poskodene data")
                return
            # uloženie do databázy - šablóna zašifrovaná kľúčom databázy
            nonce_db, sablona_db = krypto.zasifruj(kluc_db, sablona, meno.encode())
            with _zamok:
                db = _nacitaj_db()
                db[meno] = {
                    "rezim": rezim,
                    "kluc_zariadenia": verejny_kluc_zariadenia.hex(),
                    "nonce": nonce_db.hex(),
                    "sablona": sablona_db.hex(),
                }
                _uloz_db(db)
            spoj.posli("PRIJATY", "registracia ok")
            return

        # --- PRIHLASENIE ---
        podpis_zariadenia = polia[3]
        with _zamok:
            zaznam = _nacitaj_db().get(meno)
        if zaznam is None or zaznam["rezim"] != rezim:
            spoj.posli("ZAMIETNUTY", "neznamy pouzivatel")
            return

        # a) je správa naozaj od zaregistrovaného zariadenia a nezmenená?
        podpisane = sprava_vymeny + nonce + zasifrovane + verejny_jednorazovy
        if not krypto.over_podpis(rezim, bytes.fromhex(zaznam["kluc_zariadenia"]),
                                  podpisane, podpis_zariadenia):
            spoj.posli("ZAMIETNUTY", "neplatny podpis")
            return

        # b) dešifrovanie šablóny
        tajomstvo = krypto.rozbal_tajomstvo(rezim, tajny_jednorazovy, sprava_vymeny)
        aes = krypto.odvod_aes_kluc(tajomstvo)
        sablona = krypto.desifruj(aes, nonce, zasifrovane, meno.encode())
        if sablona is None:
            spoj.posli("ZAMIETNUTY", "poskodene data")
            return

        # c) porovnanie s uloženou šablónou
        ulozena = krypto.desifruj(kluc_db, bytes.fromhex(zaznam["nonce"]),
                                  bytes.fromhex(zaznam["sablona"]), meno.encode())
        zhoda, vzdialenost = biometria.porovnaj(
            biometria.z_bajtov(sablona), biometria.z_bajtov(ulozena)
        )
        if zhoda:
            spoj.posli("PRIJATY", f"vzdialenost {vzdialenost:.3f}")
        else:
            spoj.posli("ZAMIETNUTY", f"ina osoba (vzdialenost {vzdialenost:.3f})")


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def vytvor_server(adresa="127.0.0.1", port=PORT):
    priprav_kluce_servera()
    server = Server((adresa, port), Obsluha)
    server.kluce = _nacitaj_kluce()
    return server


def spusti_na_pozadi(adresa="127.0.0.1", port=PORT):
    """Spustí server vo vedľajšom vlákne (použité v meranie.py)."""
    server = vytvor_server(adresa, port)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Autentifikačný server")
    parser.add_argument("--adresa", default="127.0.0.1",
                        help="0.0.0.0 = prístupný z iných počítačov v sieti")
    parser.add_argument("--port", type=int, default=PORT)
    args = parser.parse_args()

    server = vytvor_server(args.adresa, args.port)
    print(f"Server beží na {args.adresa}:{args.port} (ukončenie: Ctrl+C)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer ukončený.")
